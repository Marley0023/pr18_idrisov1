package com.example.pr19_idrisov

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class privet : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_privet)
        sharedPreferences = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)

        val loginButton = findViewById<Button>(R.id.logVvod)
        loginButton.setOnClickListener {
            login()
        }
    }
    private fun login() {
        val usernameInput = findViewById<EditText>(R.id.userVvod)
        val passwordInput = findViewById<EditText>(R.id.passVvod)

        val username = usernameInput.text.toString()
        val password = passwordInput.text.toString()

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Пожалуйста, введите имя пользователя и пароль", Toast.LENGTH_SHORT).show()
        } else {
            saveUser(username, password)
            Toast.makeText(this, "Вход выполнен!", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, input::class.java))
        }
    }
    private fun saveUser(username: String, password: String) {
        with(sharedPreferences.edit()) {
            putString("username", username)
            putString("password", password)
            apply()
        }
    }

}