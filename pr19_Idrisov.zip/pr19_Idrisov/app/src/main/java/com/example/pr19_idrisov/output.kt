package com.example.pr19_idrisov

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class output : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_output)
        sharedPreferences = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)

        val outputText = findViewById<TextView>(R.id.outputText)
        outputText.text = loadInputData()
    }
    private fun loadInputData(): String {
        return sharedPreferences.getString("input_data", "") ?: ""
    }
}
