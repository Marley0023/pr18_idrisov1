package com.example.pr19_idrisov

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class input : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input)
        sharedPreferences = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val inputData = findViewById<EditText>(R.id.inputData)
        val saveButton = findViewById<Button>(R.id.saveButton)
        saveButton.setOnClickListener {
            val inputText = inputData.text.toString()
            saveInputData(inputText)
            Toast.makeText(this, "Данные сохранены!", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, output::class.java)) // Переход к следующему экрану
        }
    }
    private fun saveInputData(inputData: String) {
        with(sharedPreferences.edit()) {
            putString("input_data", inputData)
            apply()
        }
    }
}
