package com.example.pr19_idrisov

data class User(var username: String, var password: String, var data: String = "")